#ifndef __COURSE__
#define __COURSE__


typedef struct course_t Course;






#endif
